# Sandy Tour Guide — Twilio Voice Webhook (Prototype)

This is a minimal Node/Express server you can deploy to provide a Twilio voice webhook.
It greets the caller, captures speech using Twilio's `<Gather input="speech">`, and replies
with simple, hardcoded intents (bus terminal, taxi, translate). Replace the `/process`
handler with calls to your LLM when you're ready.

## 1) Local quick start (requires a laptop)
```bash
# Node 18+
cp .env.example .env
npm install
npm start
# In another shell, expose with ngrok
ngrok http 8080
# Copy the https URL shown by ngrok:
#   https://XYZ.ngrok-free.app
# Then set Twilio Voice webhook for your number to:
#   https://XYZ.ngrok-free.app/voice  (HTTP POST)
```

## 2) Deploy free on Render
1. Create a new **Web Service** from a public repo or upload the zip.
2. Runtime: Node 18, Build command: `npm install`, Start command: `npm start`.
3. Add environment variables (copy from `.env.example`).
4. After it deploys, you'll get a URL like `https://sandy-voice.onrender.com/voice`.
5. In Twilio Console → Phone Numbers → your number → **A call comes in** set to Webhook (HTTP POST) and paste the `/voice` URL.

## 3) Notes
- This prototype uses Twilio's built-in TTS voices via `<Say>`. You can later swap for ElevenLabs or Google TTS by returning `<Play>` with a generated audio URL.
- To support Thai ASR, set `DEFAULT_STT_LANG=th-TH` in `.env`.
- Replace logic in `/process` with your real intent handling & tools.
